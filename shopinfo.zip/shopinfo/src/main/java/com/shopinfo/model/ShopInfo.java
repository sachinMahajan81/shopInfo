package com.shopinfo.model;

public class ShopInfo {

	@Override
	public String toString() {
		return "ShopInfo [shopName=" + shopName + ", shopLongitude=" + shopLongitude + ", shopLatitude=" + shopLatitude
				+ ", shopAddress=" + shopAddress + "]";
	}
	private String shopName;
	public ShopInfo(String shopLatitude, String shopLongitude) {
		this.shopLatitude = shopLatitude;
		this.shopLongitude = shopLongitude;
	}
	public ShopInfo() {
		// TODO Auto-generated constructor stub
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopLongitude() {
		return shopLongitude;
	}
	public void setShopLongitude(String shopLongitude) {
		this.shopLongitude = shopLongitude;
	}
	public String getShopLatitude() {
		return shopLatitude;
	}
	public void setShopLatitude(String shopLatitude) {
		this.shopLatitude = shopLatitude;
	}
	private String shopLongitude;
	private String shopLatitude;
	private ShopAddress shopAddress;
	
	
	public Object getShopAddress() {
		return shopAddress;
	}
	public void setShopAddress(ShopAddress shopAddress) {
		this.shopAddress = shopAddress;
	}
}
