package com.shopinfo.model;

public class ShopAddress {
	private String number;
	public String getNumber() {
		return number;
	}
	@Override
	public String toString() {
		return "ShopAddress [number=" + number + ", postalCode=" + postalCode + "]";
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	private String postalCode;
}
