package com.shopinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ShopinfoApplication {
		public static void main(String[] args) {
		SpringApplication.run(ShopinfoApplication.class, args);
	}
}
