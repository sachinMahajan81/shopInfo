package com.shopinfo.controller;

import java.util.ArrayList;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.shopinfo.model.ShopInfo;
import com.shopinfo.processor.ShopInfoProcessor;

@RestController
public class ShopInfoController {

@Autowired
private ShopInfoProcessor shopInfoProcessor;



private List<ShopInfo> ShopInfoList=  new ArrayList<ShopInfo>();

@SuppressWarnings("finally")
@RequestMapping(value = "/saveShopInfo")
/*
 * This method is used to save shopInfo after getting its latitide and longitude value through geocoding API
 * This method takes shopInfo object from payload and is passed to further processing.
 * After getting full ShopInfo object from processor, object is saved in in-memory Array List
 * and is also returned to REST Client.
 */
public Object saveShopInfo(@RequestBody ShopInfo shopInfo) {
    
	try{
		if(shopInfo!=null){
			shopInfo = shopInfoProcessor.saveShopInfo(shopInfo);
			ShopInfoList.add(shopInfo);
		}
	}catch(Exception e ){
		 System.out.println("Exception in saveShopInfo------------"  +e.getMessage());
		 return "Error in Saving Shop info";
	}
	finally{
		return shopInfo;
	}
	
    
	
}
@SuppressWarnings("finally")
@RequestMapping(value = "/getShopInfo")
/*
 * This method is used to get shopInfo object through geocoding API
 * This method takes customerLongitude, customerLatitude values from URL and are passed to pr further processor further processing
 * After getting full ShopInfo Array List from processor, same is also returned to REST Client.
 */
public Object getShopInfo(@RequestParam(value="customerLongitude", defaultValue="12345") String customerLongitude, 
		@RequestParam(value="customerLatitude", defaultValue="5678") String customerLatitude) {
	 ArrayList<ShopInfo> shopInfoArrayList = new ArrayList<ShopInfo>();
	
	try{
		shopInfoArrayList = shopInfoProcessor.getShopInfo(customerLongitude, customerLatitude);
	}catch(Exception e ){
		 System.out.println("Exception in getShopInfo------------"  +e.getMessage());
		return "Error in Saving Shop info";
	}
	finally{
		
		return shopInfoArrayList;
	}
	
    
	
}

}
