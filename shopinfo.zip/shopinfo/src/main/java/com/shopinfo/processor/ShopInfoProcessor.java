package com.shopinfo.processor;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Component;

import com.shopinfo.model.AddressComponents;
import com.shopinfo.model.GoogleResponse;
import com.shopinfo.model.Result;
import com.shopinfo.model.ShopAddress;
import com.shopinfo.model.ShopInfo;

/**
 * 
 * 
 * @author Sachin Mahajan
 * 
 */
@Component
public class ShopInfoProcessor {


 /*
  * Geocode request URL. Here see we are passing "json" it means we will get
  * the output in JSON format. 
  * 
  */

private static final String URL = "http://maps.googleapis.com/maps/api/geocode/json";
private static final Object TYPE_ESTABLISHMENT = "establishment";
private static final Object TYPE_POSTAL_CODE = "postal_code";

 /*
  * Here the postalCode is string containing postal code of shop. 
  * .
  */
 public GoogleResponse convertToLatLong(String postalCode) throws IOException {

  /*
   * Create an java.net.URL object by passing the request URL in
   * constructor. Here you can see I am converting the fullAddress String
   * in UTF-8 format. You will get Exception if you don't convert your
   * address in UTF-8 format. Perhaps google loves UTF-8 format. :) In
   * parameter we also need to pass "sensor" parameter. sensor (required
   * parameter) — Indicates whether or not the geocoding request comes
   * from a device with a location sensor. This value must be either true
   * or false.
   */
  URL url = new URL(URL + "?address="
    + URLEncoder.encode(postalCode, "UTF-8") + "&sensor=false");
  // Open the Connection
  URLConnection conn = url.openConnection();

  InputStream in = conn.getInputStream() ;
  ObjectMapper mapper = new ObjectMapper();
  GoogleResponse response = (GoogleResponse)mapper.readValue(in,GoogleResponse.class);
  in.close();
  return response;
  

 }
 
 public GoogleResponse convertFromLatLong(String latlongString) throws IOException {

  /*
   * Create an java.net.URL object by passing the request URL in
   * constructor. Here you can see I am converting the fullAddress String
   * in UTF-8 format. You will get Exception if you don't convert your
   * address in UTF-8 format. Perhaps google loves UTF-8 format. :) In
   * parameter we also need to pass "sensor" parameter. sensor (required
   * parameter) — Indicates whether or not the geocoding request comes
   * from a device with a location sensor. This value must be either true
   * or false.
   */
  URL url = new URL(URL + "?latlng="
    + URLEncoder.encode(latlongString, "UTF-8") + "&sensor=false");
  // Open the Connection
  URLConnection conn = url.openConnection();

  InputStream in = conn.getInputStream() ;
  ObjectMapper mapper = new ObjectMapper();
  GoogleResponse response = (GoogleResponse)mapper.readValue(in,GoogleResponse.class);
  in.close();
  return response;
  

 }
 /*
  * Here ShopInfo object contains all the shop details need to be saved.
  * Based upon the shop details, latitude and longitude with fetched through geocoding API and
  * will added in shopInfo object being returned by this method.   
  */
 
 public ShopInfo saveShopInfo(ShopInfo shopInfo) throws IOException{
	
	
	if(shopInfo.getShopAddress() != null && ((ShopAddress)shopInfo.getShopAddress()).getPostalCode() !=null){
	 GoogleResponse res = convertToLatLong(((ShopAddress)shopInfo.getShopAddress()).getPostalCode());
		  
		  if(res.getStatus().equals("OK"))
		  {
			   for(Result result : res.getResults())
			   {
			    shopInfo.setShopLatitude(result.getGeometry().getLocation().getLat());
			    shopInfo.setShopLongitude(result.getGeometry().getLocation().getLng());
			    
			   }
		  }
		  else
		  {
		   System.out.println(res.getStatus());
		  }
		  
	 }
	 
	 return shopInfo;
	  
	 
 }
 
 /*
  * Here customerLongitude, customerLatitude will be passed to geocoding API and
  * based upon that nearest entities will be returned by the API.
  * The results returned by geocoding API is further filtered based upon type as "establishment"
  * and shopInfo objects are created with corresponding info and are added to an array list of type <ShopInfo>
  * being returned by this method.   
  */
 public ArrayList<ShopInfo> getShopInfo(String customerLongitude,String customerLatitude) throws IOException{
	 ArrayList<ShopInfo> shopInfoArrayList = new ArrayList<ShopInfo>();
	 
	ShopInfo currShopInfo = new ShopInfo(); 
	ShopAddress currShopAddress = new ShopAddress();
	GoogleResponse res = convertFromLatLong(customerLatitude+","+customerLongitude);
		  
		  if(res.getStatus().equals("OK"))
		  {
			   for(Result result : res.getResults())
			   {
					currShopInfo = new ShopInfo(); 
					currShopAddress = new ShopAddress();
				    
				    currShopInfo.setShopLatitude(result.getGeometry().getLocation().getLat());
				    currShopInfo.setShopLongitude(result.getGeometry().getLocation().getLng());
				    
				    if(result.getTypes()!=null && result.getTypes().contains(TYPE_ESTABLISHMENT))
				    	for(AddressComponents addComp : result.getAddress_components()){
					    	
					    	if(addComp.getTypes()!=null && addComp.getTypes().contains(TYPE_ESTABLISHMENT)){
					    		currShopInfo.setShopName(addComp.getLong_name());
					    	}
					    	else if(addComp.getTypes()!=null && addComp.getTypes().contains(TYPE_POSTAL_CODE)){
					    		currShopAddress.setPostalCode(addComp.getLong_name());
					    		currShopAddress.setNumber("tempNumber");
					    		
					    	}
					    }
					    currShopInfo.setShopAddress(currShopAddress);
				    	shopInfoArrayList.add(currShopInfo);
				    
				   }
		  }
		  else
		  {
		   System.out.println(res.getStatus());
		  }

	 

		  return shopInfoArrayList;
	  
	 
 }
 

}

